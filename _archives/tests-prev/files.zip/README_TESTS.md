# Tests Cryptocalc - Guide Complet

## 🎯 Vue d'ensemble

Cryptocalc utilise **DEUX frameworks de test séparés** :

```
┌─────────────────────────────────────────────────────────┐
│                   TESTS CRYPTOCALC                      │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ┌──────────────────┐         ┌──────────────────┐    │
│  │      JEST        │         │   PLAYWRIGHT     │    │
│  ├──────────────────┤         ├──────────────────┤    │
│  │ • Tests unitaires│         │ • Tests E2E GUI  │    │
│  │ • Tests API      │         │ • ElectronJS     │    │
│  │ • Tests intégr.  │         │ • Interface      │    │
│  │                  │         │                  │    │
│  │ npm test         │         │ npm run gui:e2e  │    │
│  └──────────────────┘         └──────────────────┘    │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

## 📁 Structure des Dossiers

```
tests/
├── jest.setup.js                 # Setup optionnel pour Jest
├── unit/                         # ✅ JEST - Tests unitaires
│   ├── core/
│   ├── crypto/
│   └── utils/
├── integration/                  # ✅ JEST - Tests d'intégration
│   └── api/
├── api/                          # ✅ JEST - Tests API (custom runners)
│   ├── runners/
│   └── specs/
└── playwright/                   # ❌ PAS JEST - Tests Playwright
    ├── config/
    │   ├── playwright.config.js  # Config Playwright (≠ Jest)
    │   └── test-setup.js         # Setup Playwright
    ├── e2e/                      # Tests E2E
    │   └── *.spec.js
    └── pages/                    # Page Objects
```

## 🔧 Configuration

### Jest (`jest.config.js`)
```javascript
// Gère UNIQUEMENT :
testMatch: [
  '**/tests/unit/**/*.test.js',
  '**/tests/integration/**/*.test.js',
  '**/tests/api/specs/**/*.test.js'
],

// Ignore explicitement Playwright :
testPathIgnorePatterns: [
  '/tests/playwright/'  // ⚠️ IMPORTANT
]
```

### Playwright (`tests/playwright/config/playwright.config.js`)
```javascript
// Configuration séparée pour tests E2E
export default {
  testDir: '../e2e',
  testMatch: '**/*.spec.js',  // Fichiers .spec.js
  // ... config Electron/GUI
}
```

## 🚀 Commandes

### Tests JEST (Unitaires + API)
```bash
# Tous les tests Jest
npm test

# Avec couverture
npm test -- --coverage

# Mode watch
npm test -- --watch

# Test spécifique
npm test -- entropy.test.js

# Verbose
npm test -- --verbose
```

### Tests PLAYWRIGHT (E2E GUI)
```bash
# Tous les tests Playwright
npm run gui:e2e

# Mode UI interactif
npm run gui:e2e:ui

# Mode visible (headed)
npm run gui:e2e:headed

# Mode debug
npm run gui:e2e:debug

# Rapport
npm run gui:e2e:report
```

### Tests API (Custom Runners)
```bash
# Tests rapides
npm run api:smoke

# Simple wallet
npm run api:simple

# Tous les simple wallets
npm run api:allsimple

# Tous les HD wallets
npm run api:allhd

# Diagnostic
npm run api:diagnostic

# Tous les tests API
npm run api:alltests
```

## 📝 Créer un Nouveau Test

### Test Jest (Unitaire)
```javascript
// tests/unit/crypto/my-feature.test.js

describe('My Crypto Feature', () => {
  test('should generate valid output', () => {
    const result = myCryptoFunction('input');
    expect(result).toBeDefined();
    expect(result.length).toBe(64);
  });
});
```

**Exécution :**
```bash
npm test -- my-feature.test.js
```

### Test Playwright (E2E)
```javascript
// tests/playwright/e2e/wallet-generation.spec.js

import { test, expect } from '@playwright/test';

test('should generate Bitcoin wallet', async ({ page }) => {
  await page.click('#btn-generate');
  await expect(page.locator('#wallet-address')).toBeVisible();
});
```

**Exécution :**
```bash
npm run gui:e2e -- wallet-generation
```

## ⚠️ Points Importants

### 1. Jest NE lance PAS Playwright
```bash
npm test  # ❌ Ne lance PAS les tests .spec.js de Playwright
```

### 2. Playwright NE lance PAS Jest
```bash
npm run gui:e2e  # ❌ Ne lance PAS les tests .test.js de Jest
```

### 3. Extensions de Fichiers
- **Jest** : `*.test.js` (dans tests/unit, tests/integration, tests/api/specs)
- **Playwright** : `*.spec.js` (dans tests/playwright/e2e)

### 4. Deux Configurations Séparées
- **Jest** : `jest.config.js` (racine projet)
- **Playwright** : `tests/playwright/config/playwright.config.js`

## 🎬 Workflow Complet

### Développement Local
```bash
# 1. Tests unitaires rapides
npm test

# 2. Tests API spécifiques
npm run api:smoke

# 3. Tests E2E GUI (si besoin)
npm run gui:e2e
```

### CI/CD
```bash
# Tous les tests Jest
npm test -- --coverage

# Tous les tests Playwright
npm run gui:e2e

# Ou script personnalisé
node tests/run-all-tests.js
```

## 📊 Rapports

### Jest
- Console : Automatique
- HTML : `coverage/test-report.html`
- Couverture : `coverage/index.html`

### Playwright
- Console : Automatique
- HTML : `npm run gui:e2e:report`
- Rapports : `tests/playwright-report/`

## 🐛 Debugging

### Jest
```bash
# Mode debug Node.js
node --inspect-brk node_modules/.bin/jest --runInBand

# Ou dans VSCode (launch.json)
{
  "type": "node",
  "request": "launch",
  "name": "Jest Debug",
  "program": "${workspaceFolder}/node_modules/.bin/jest",
  "args": ["--runInBand"],
  "console": "integratedTerminal"
}
```

### Playwright
```bash
# Mode debug Playwright
npm run gui:e2e:debug

# Ou
PWDEBUG=1 npm run gui:e2e
```

## 📚 Ressources

- [Jest Documentation](https://jestjs.io/)
- [Playwright Documentation](https://playwright.dev/)
- [Playwright pour Electron](https://playwright.dev/docs/api/class-electron)

## ❓ FAQ

**Q: Pourquoi deux frameworks ?**
A: Jest est excellent pour tests unitaires/API Node.js. Playwright est spécialisé pour tests E2E d'interfaces graphiques (Electron).

**Q: Comment lancer tous les tests ?**
A: Créez un script qui lance Jest puis Playwright :
```bash
npm test && npm run gui:e2e
```

**Q: Puis-je utiliser Jest pour tester l'UI ?**
A: Non, Jest ne peut pas contrôler Electron. Utilisez Playwright pour les tests GUI.

**Q: Les tests Playwright sont lents ?**
A: Oui, c'est normal. Les tests E2E lancent l'application complète. Utilisez Jest pour les tests rapides.
