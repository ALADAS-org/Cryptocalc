#!/usr/bin/env node
/**
 * ============================================================================
 * Script pour exécuter TOUS les tests (Jest + Playwright)
 * ============================================================================
 * Usage: node tests/run-all-tests.js [options]
 * 
 * Options:
 *   --skip-unit      Skip Jest unit tests
 *   --skip-gui       Skip Playwright GUI tests
 *   --coverage       Run Jest with coverage
 *   --headed         Run Playwright in headed mode
 * ============================================================================
 */

const { spawn } = require('child_process');
const path = require('path');

// ==========================================================================
// CONFIGURATION
// ==========================================================================

const args = process.argv.slice(2);
const options = {
  skipUnit: args.includes('--skip-unit'),
  skipGui: args.includes('--skip-gui'),
  coverage: args.includes('--coverage'),
  headed: args.includes('--headed')
};

// Couleurs console
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  red: '\x1b[31m',
  cyan: '\x1b[36m'
};

// ==========================================================================
// HELPERS
// ==========================================================================

function log(message, color = colors.reset) {
  console.log(`${color}${message}${colors.reset}`);
}

function logSection(title) {
  console.log('\n' + '='.repeat(80));
  log(title, colors.bright + colors.cyan);
  console.log('='.repeat(80) + '\n');
}

function runCommand(command, args, options = {}) {
  return new Promise((resolve, reject) => {
    log(`$ ${command} ${args.join(' ')}`, colors.yellow);
    
    const child = spawn(command, args, {
      stdio: 'inherit',
      shell: true,
      ...options
    });

    child.on('close', (code) => {
      if (code !== 0) {
        reject(new Error(`Command failed with exit code ${code}`));
      } else {
        resolve();
      }
    });

    child.on('error', (error) => {
      reject(error);
    });
  });
}

// ==========================================================================
// TESTS JEST
// ==========================================================================

async function runJestTests() {
  logSection('📦 TESTS JEST (Unitaires + Intégration)');
  
  const jestArgs = [];
  
  if (options.coverage) {
    jestArgs.push('--coverage');
  }
  
  try {
    await runCommand('npm', ['test', '--', ...jestArgs]);
    log('✅ Tests Jest réussis\n', colors.green);
    return true;
  } catch (error) {
    log('❌ Tests Jest échoués\n', colors.red);
    log(error.message, colors.red);
    return false;
  }
}

// ==========================================================================
// TESTS PLAYWRIGHT
// ==========================================================================

async function runPlaywrightTests() {
  logSection('🎭 TESTS PLAYWRIGHT (E2E GUI)');
  
  const playwrightCmd = options.headed ? 'gui:e2e:headed' : 'gui:e2e';
  
  try {
    await runCommand('npm', ['run', playwrightCmd]);
    log('✅ Tests Playwright réussis\n', colors.green);
    return true;
  } catch (error) {
    log('❌ Tests Playwright échoués\n', colors.red);
    log(error.message, colors.red);
    return false;
  }
}

// ==========================================================================
// MAIN
// ==========================================================================

async function main() {
  logSection('🧪 EXÉCUTION DE TOUS LES TESTS - Cryptocalc');
  
  const startTime = Date.now();
  const results = {
    jest: null,
    playwright: null
  };

  // Afficher les options
  if (options.skipUnit || options.skipGui || options.coverage || options.headed) {
    log('Options:', colors.cyan);
    if (options.skipUnit) log('  - Skip Jest tests', colors.yellow);
    if (options.skipGui) log('  - Skip Playwright tests', colors.yellow);
    if (options.coverage) log('  - Jest coverage enabled', colors.cyan);
    if (options.headed) log('  - Playwright headed mode', colors.cyan);
    console.log('');
  }

  // Exécuter Jest
  if (!options.skipUnit) {
    results.jest = await runJestTests();
  } else {
    log('⏭️  Tests Jest ignorés\n', colors.yellow);
    results.jest = true;
  }

  // Exécuter Playwright
  if (!options.skipGui) {
    results.playwright = await runPlaywrightTests();
  } else {
    log('⏭️  Tests Playwright ignorés\n', colors.yellow);
    results.playwright = true;
  }

  // Résumé
  const endTime = Date.now();
  const duration = ((endTime - startTime) / 1000).toFixed(2);
  
  logSection('📊 RÉSUMÉ DES TESTS');
  
  if (!options.skipUnit) {
    log(`Jest:       ${results.jest ? '✅ PASS' : '❌ FAIL'}`, 
        results.jest ? colors.green : colors.red);
  }
  
  if (!options.skipGui) {
    log(`Playwright: ${results.playwright ? '✅ PASS' : '❌ FAIL'}`, 
        results.playwright ? colors.green : colors.red);
  }
  
  console.log('');
  log(`Durée totale: ${duration}s`, colors.cyan);
  console.log('='.repeat(80));

  // Exit code
  const allPassed = results.jest && results.playwright;
  if (allPassed) {
    log('\n🎉 Tous les tests sont passés !\n', colors.bright + colors.green);
    process.exit(0);
  } else {
    log('\n❌ Certains tests ont échoué\n', colors.bright + colors.red);
    process.exit(1);
  }
}

// ==========================================================================
// EXECUTION
// ==========================================================================

main().catch((error) => {
  log('\n💥 Erreur fatale:', colors.red);
  console.error(error);
  process.exit(1);
});
