/**
 * ============================================================================
 * Configuration globale Jest pour Cryptocalc
 * ============================================================================
 * Fichier exécuté avant tous les tests Jest
 * Configure l'environnement de test global
 * 
 * Pour activer : Décommenter setupFilesAfterEnv dans jest.config.js
 * ============================================================================
 */

// ==========================================================================
// CONFIGURATION DES TIMEOUTS
// ==========================================================================

// Augmente le timeout pour les opérations cryptographiques lentes
jest.setTimeout(10000);

// ==========================================================================
// CONFIGURATION DE L'ENVIRONNEMENT
// ==========================================================================

// Force l'environnement de test
process.env.NODE_ENV = 'test';
process.env.TEST_MODE = 'true';

// ==========================================================================
// MATCHERS PERSONNALISÉS
// ==========================================================================

/**
 * Matchers personnalisés pour les tests crypto
 */
expect.extend({
  /**
   * Vérifie qu'une valeur est une adresse crypto valide
   */
  toBeValidAddress(received) {
    const pass = typeof received === 'string' && received.length > 20;
    return {
      message: () =>
        pass
          ? `expected ${received} not to be a valid crypto address`
          : `expected ${received} to be a valid crypto address`,
      pass,
    };
  },

  /**
   * Vérifie qu'une valeur est une clé privée valide
   */
  toBeValidPrivateKey(received) {
    const pass = typeof received === 'string' && (
      received.length === 64 ||  // Hex format
      received.length === 52     // WIF format
    );
    return {
      message: () =>
        pass
          ? `expected ${received} not to be a valid private key`
          : `expected ${received} to be a valid private key`,
      pass,
    };
  },

  /**
   * Vérifie qu'une valeur est une phrase mnémonique valide
   */
  toBeValidMnemonic(received) {
    const wordCount = received ? received.split(' ').length : 0;
    const validCounts = [12, 15, 18, 21, 24];
    const pass = validCounts.includes(wordCount);
    return {
      message: () =>
        pass
          ? `expected ${wordCount} words not to be a valid mnemonic length`
          : `expected ${wordCount} words to be a valid mnemonic length (12, 15, 18, 21, or 24)`,
      pass,
    };
  },

  /**
   * Vérifie qu'une valeur est une chaîne hexadécimale valide
   */
  toBeHexString(received) {
    const hexRegex = /^[0-9a-fA-F]+$/;
    const pass = typeof received === 'string' && hexRegex.test(received);
    return {
      message: () =>
        pass
          ? `expected ${received} not to be a hex string`
          : `expected ${received} to be a hex string`,
      pass,
    };
  },

  /**
   * Vérifie qu'une valeur est un JSON valide
   */
  toBeValidJSON(received) {
    let pass = false;
    try {
      JSON.parse(received);
      pass = true;
    } catch (e) {
      pass = false;
    }
    return {
      message: () =>
        pass
          ? `expected ${received} not to be valid JSON`
          : `expected ${received} to be valid JSON`,
      pass,
    };
  }
});

// ==========================================================================
// MOCKS GLOBAUX
// ==========================================================================

// Mock console pour réduire le bruit dans les tests
global.console = {
  ...console,
  // Garde les erreurs visibles
  error: jest.fn(console.error),
  // Silence les logs normaux sauf si DEBUG=true
  log: process.env.DEBUG ? console.log : jest.fn(),
  warn: process.env.DEBUG ? console.warn : jest.fn(),
  info: process.env.DEBUG ? console.info : jest.fn(),
  debug: process.env.DEBUG ? console.debug : jest.fn(),
};

// ==========================================================================
// NETTOYAGE APRÈS CHAQUE TEST
// ==========================================================================

afterEach(() => {
  // Nettoie les mocks après chaque test
  jest.clearAllMocks();
});

// ==========================================================================
// CONFIGURATION GLOBALE
// ==========================================================================

// Variables globales disponibles dans tous les tests
global.testConfig = {
  defaultEntropySize: 256,
  defaultBlockchain: 'bitcoin',
  supportedEntropySizes: [128, 160, 192, 224, 256],
  supportedBlockchains: [
    'bitcoin', 
    'ethereum', 
    'litecoin', 
    'dogecoin', 
    'solana', 
    'avalanche', 
    'polygon', 
    'toncoin', 
    'terra'
  ],
  walletTypes: ['SIMPLE_WALLET', 'HD_WALLET', 'SWORD_WALLET']
};

// ==========================================================================
// HELPERS GLOBAUX
// ==========================================================================

/**
 * Helper pour créer des données de test répétables
 */
global.createTestEntropy = (size = 256) => {
  return '0'.repeat(size / 4); // Crée une chaîne hex de la bonne taille
};

/**
 * Helper pour créer une phrase mnémonique de test
 */
global.createTestMnemonic = (wordCount = 12) => {
  const words = [
    'abandon', 'ability', 'able', 'about', 'above', 'absent',
    'absorb', 'abstract', 'absurd', 'abuse', 'access', 'accident',
    'account', 'accuse', 'achieve', 'acid', 'acoustic', 'acquire',
    'across', 'act', 'action', 'actor', 'actress', 'actual'
  ];
  return words.slice(0, wordCount).join(' ');
};

/**
 * Helper pour attendre un certain temps
 */
global.wait = (ms) => new Promise(resolve => setTimeout(resolve, ms));

/**
 * Helper pour créer un wallet de test
 */
global.createTestWallet = () => ({
  address: '1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa',
  privateKey: '0'.repeat(64),
  publicKey: '0'.repeat(66),
  wif: 'L1uyy5qTuGrVXrmrsvHWHgVzW9kKdrp27wBC7Vs6nZDTF2BRUVwy'
});

// ==========================================================================
// INFORMATIONS DE DEBUG
// ==========================================================================

if (process.env.DEBUG) {
  console.log('='.repeat(80));
  console.log('🧪 JEST SETUP - Configuration de test chargée');
  console.log('='.repeat(80));
  console.log('Node version:', process.version);
  console.log('Platform:', process.platform);
  console.log('Architecture:', process.arch);
  console.log('Working directory:', process.cwd());
  console.log('Test environment:', process.env.NODE_ENV);
  console.log('='.repeat(80));
}
